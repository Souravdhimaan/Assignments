// side_bar_code
function toggleNav() {
  const sidebar = document.getElementById("mySidebar");
  const main = document.getElementById("main");

  if (sidebar.style.width === "250px") {
    sidebar.style.width = "0";
    main.style.marginLeft = "0";
  } else {
    sidebar.style.width = "250px";
    main.style.marginLeft = "250px";
  }
}
// side_bar_code_close

// uploa_content_btn_for_second_file
function uploadcontent() {
  window.open("../html/details.html");
}
// upload_content_btn_code_close

// data_save_and_print
const user_details = JSON.parse(localStorage.getItem("user_details"));
const outputDiv = document.getElementById("output");
const table = document.createElement("table");
table.style.border = "1px solid";

const headerRow = document.createElement("tr");
headerRow.style.backgroundColor = "black";
headerRow.style.color = "black";
const headers = [];
headers.forEach((headerText) => {
  const header = document.createElement("th");
  header.textContent = headerText;
  header.style.padding = "10px";
  headerRow.appendChild(header);
  cell.style.width = "100%";
});
table.appendChild(headerRow);

if (user_details && user_details.length > 0) {
  user_details.forEach((detail) => {
    const row = document.createElement("tr");
    const values = [
      detail.title,
      detail.company,
      detail.jobNumber,
      detail.copyrightnotice,
      detail.pre_date,
      detail.exp_date,
    ];
    values.forEach((value) => {
      const cell = document.createElement("td");
      cell.textContent = value;
      cell.style.border = "1px solid white";
      cell.style.padding = "10px";
      cell.style.width = "190.6px";
      cell.style.color = "white";
      row.appendChild(cell);
    });
    table.appendChild(row);
  });
}
outputDiv.appendChild(table);
// data_save_and_print_close

// searching_by_title
function search() {
  const searchInput = document
    .getElementById("searchInput")
    .value.toLowerCase();
  const user_details = JSON.parse(localStorage.getItem("user_details"));

  const filteredData = user_details.filter((detail) =>
    detail.title.toLowerCase().includes(searchInput)
  );

  displayData(filteredData);
}

function displayData(data) {
  const outputDiv = document.getElementById("output");
  outputDiv.innerHTML = "";

  if (data.length === 0) {
    outputDiv.textContent = "No Result Found";
    return;
  }

  const table = document.createElement("table");
  table.style.border = "1px solid white";

  const headerRow = document.createElement("tr");
  headerRow.style.backgroundColor = "black";
  headerRow.style.color = "white";

  headers.forEach((headerText) => {
    const header = document.createElement("th");
    header.textContent = headerText;
    header.style.padding = "10px";
    headerRow.appendChild(header);
  });

  table.appendChild(headerRow);

  data.forEach((detail) => {
    const row = document.createElement("tr");
    const values = [
      detail.title,
      detail.company,
      detail.jobNumber,
      detail.copyrightnotice,
      detail.pre_date,
      detail.exp_date,
    ];

    values.forEach((value) => {
      const cell = document.createElement("td");
      cell.textContent = value;
      cell.style.border = "1px solid white";
      cell.style.padding = "10px";
      cell.style.width = "190.6px";
      cell.style.color = "white";
      row.appendChild(cell);
    });

    table.appendChild(row);
  });

  outputDiv.appendChild(table);
}
// // searching_by_title_close
