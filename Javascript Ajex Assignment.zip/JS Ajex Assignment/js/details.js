// side_bar
function toggleNav() {
  const sidebar = document.getElementById("mySidebar");
  const main = document.getElementById("main");

  if (sidebar.style.width === "250px") {
    sidebar.style.width = "0";
    main.style.marginLeft = "0";
  } else {
    sidebar.style.width = "250px";
    main.style.marginLeft = "250px";
  }
}
// side_bar_close

// details_validation
function validateForm() {
  resetFieldStyles();

  let title = document.getElementById("fname");
  let company = document.getElementById("company");
  let onelinedescription = document.getElementById("onelinedescription");
  let description = document.getElementById("description");
  var preDateInput = document.getElementById('pre_date');
  var expDateInput = document.getElementById('exp_date');
  let jobNumber = document.getElementById("job_number");
  let copyrightnotice = document.getElementById("copy_right_notice");

  let isValid = true;

  if (title.value.trim() === "") {
    setFieldError(title);
    isValid = false;
  }

  if (company.value === "Select") {
    setFieldError(company);
    isValid = false;
  }

  if (onelinedescription.value.trim() === "") {
    setFieldError(onelinedescription);
    isValid = false;
  }

  if (description.value.trim() === "") {
    setFieldError(description);
    isValid = false;
  }

  if (jobNumber.value.trim() === "") {
    setFieldError(jobNumber);
    isValid = false;
  }

  if (copyrightnotice.value.trim() === "") {
    setFieldError(copyrightnotice);
    isValid = false;
  }
  if (isValid) {
    // Store data in local storage
    let user_details;
    if (localStorage.getItem("user_details") == null) {
      user_details = [];
    } else {
      user_details = JSON.parse(localStorage.getItem("user_details"));
    }

    user_details.push({
      title: title.value,
      company: company.value,
      jobNumber: jobNumber.value,
      copyrightnotice: copyrightnotice.value,
      pre_date: pre_date.value,
      exp_date: exp_date.value,
    });

    localStorage.setItem("user_details", JSON.stringify(user_details));

    title.value = "";
    company.value = "Select";
    jobNumber.value = "";
    copyrightnotice.value = "";
    pre_date.value = "";
    exp_date.value = "";
  }
  //// Store data in local storage_close
  return isValid;
}

function resetForm() {
  resetFieldStyles();
  document.getElementById("myForm").reset();
}

function resetFieldStyles() {
  let fields = document.querySelectorAll(".details_form");
  fields.forEach(function (field) {
    field.classList.remove("error", "success");
  });
}

function setFieldError(field) {
  field.classList.add("error");
}

// details_validation_close

// behaviour_file_open
function next() {
  if (validateForm()) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4 && xhr.status === 200) {
        document.getElementById("new_file").innerHTML = xhr.responseText;
      }
    };
    xhr.open("GET", "../html/behaviour.html", true);
    xhr.send();
  }
}
// behaviour_file_code_close

// tag_file_open
function fourth() {
  const radioButtons = document.querySelectorAll('input[type="radio"]');
  let isRadioButtonSelected = false;

  for (const radioButton of radioButtons) {
    if (radioButton.checked) {
      isRadioButtonSelected = true;
      break;
    }
  }

  if (isRadioButtonSelected) {
    document
      .getElementById("tag_file_open")
      .addEventListener("click", function () {
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("new_file").innerHTML = xhr.responseText;

            // image_upload
            const fileInput = document.getElementById("fileInput");
            const uploadedImage = document.getElementById("uploadedImage");
            const greenTickIcon = document.querySelector(".green_tick_icon");

            fileInput.addEventListener("change", function () {
              const file = this.files[0];

              if (file) {
                const reader = new FileReader();

                reader.addEventListener("load", function (e) {
                  uploadedImage.src = e.target.result;
                  greenTickIcon.style.display = "inline";
                });

                reader.readAsDataURL(file);
              } else {
                greenTickIcon.style.display = "none";
              }
            });

            // image_upload_close

            // popup
            const openPopupButton = document.getElementById("openPopup");
            const closePopupButton = document.getElementById("closePopup");
            const popup_main = document.getElementById("popup_main");

            openPopupButton.addEventListener("click", () => {
              popup_main.style.display = "flex";
            });

            closePopupButton.addEventListener("click", () => {
              popup_main.style.display = "none";
            });
            // popup_close

            // third_screen_back_code
            document
              .getElementById("third_screen")
              .addEventListener("click", function () {
                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                  if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById("new_file").innerHTML =
                      xhr.responseText;
                  }
                };

                xhr.open("GET", "../html/behaviour.html", true);

                xhr.send();
              });
            // third_screen_back_code_close
          }
        };

        xhr.open("GET", "../html/tag.html", true);

        xhr.send();
      });
  } else {
    alert("Please Select all Radio Buttons");
  }
}