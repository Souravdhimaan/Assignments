const navbar = document.getElementById("navbar");
const headerHeight = document.querySelector(".header").offsetHeight;

function updateBackgroundColor() {
  if (window.scrollY < headerHeight) {
    navbar.style.backgroundColor = "transparent";
  } else {
    navbar.style.backgroundColor = "#81AF85";
  }
}

window.addEventListener("scroll", updateBackgroundColor);
updateBackgroundColor();
