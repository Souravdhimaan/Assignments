// cart_update
function updateCartUI() {
  const cartList = document.getElementById("cart-list");
  cartList.innerHTML = "";

// Data_print
  const cartItems = getCartItems();

  cartItems.forEach((item, index) => {
    const listItem = document.createElement("li");
    listItem.innerHTML = `
          <div class="cart-item-content">
            <img src="${item.imageUrl}" class="cart-item-image">
            <div class="item-details">
              <span class="product-name">${item.productName}</span>
              <span class="product-price">$${item.price}</span>
            </div>
            
            <button class="buy_button" onclick="buy_product(${index})">Buy</button> 
            <button class="remove-button" onclick="removeFromCart(${index})">X</button>
          </div>
        `;
    cartList.appendChild(listItem);
  });
}

// data_get_from_local_storage
function getCartItems() {
  return JSON.parse(localStorage.getItem("cartItems")) || [];
}

// delete_cart_data
function removeFromCart(index) {
  const cartItems = getCartItems();
  cartItems.splice(index, 1);
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
  updateCartUI();
}

window.onload = function () {
  updateCartUI();
};

// form_file_open_code
function buy_product(index) {
  const cartItems = getCartItems();
  const selectedProduct = cartItems[index];
  localStorage.setItem("selectedProduct", JSON.stringify(selectedProduct));
  window.open("../html/form.html");
}

