// Cart_product_add_in_local_storage
function addToCart(productName, price, imageUrl) {
  const cartItem = {
    productName: productName,
    price: price,
    imageUrl: imageUrl,
  };

  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  cartItems.push(cartItem);

  localStorage.setItem("cartItems", JSON.stringify(cartItems));
  updateCartUI();
}

// favourite_product_add_in_local_storage
function addTofavourite(productName, price, imageUrl) {
  const favouriteItem = {
    productName: productName,
    price: price,
    imageUrl: imageUrl,
  };

  const favouriteItems =JSON.parse(localStorage.getItem("favouriteItems")) || [];
  favouriteItems.push(favouriteItem);

  localStorage.setItem("favouriteItems", JSON.stringify(favouriteItems));
  updateCartUI();
}
