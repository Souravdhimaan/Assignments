// data_get_from_local_storage
function getfavouriteItems() {
  return JSON.parse(localStorage.getItem('favouriteItems')) || [];
}

// data_print_favourite_&_update
function updateFavouritesUI() {
  const favouriteItems = getfavouriteItems();
  const cartList = document.getElementById('favourite-list');
  cartList.innerHTML = ''; 

  favouriteItems.forEach((item, index) => {
      const listItem = document.createElement('li');
      listItem.innerHTML = `
          <div class="fav-item-content">
              <img src="${item.imageUrl}">
              <div class="item-details">
                  <span class="product-name">${item.productName}</span>
                  <span class="product-price">$${item.price}</span>
              </div>

              <i onclick="buy_product(${index})" class="fa-solid fa-cart-shopping favourite_to_cart_btn"></i>
              <button class="remove-button" onclick="removeFromFavourites(${index})">X</button>
          </div>
      `;
      cartList.appendChild(listItem);
  });
}

// delete_favourite_data
function removeFromFavourites(index) {
  const favouriteItems = getfavouriteItems();
  favouriteItems.splice(index, 1);
  localStorage.setItem('favouriteItems', JSON.stringify(favouriteItems));
  updateFavouritesUI(); 
}

window.onload = function () {
  updateFavouritesUI();
};
