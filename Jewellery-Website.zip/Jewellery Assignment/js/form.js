// from_page_data_get
document.addEventListener("DOMContentLoaded", function () {
  const selectedProduct = JSON.parse(localStorage.getItem("selectedProduct"));

  if (selectedProduct) {
    const productNameField = document.getElementById("product-name");
    const productPriceField = document.getElementById("product-price");
    const productImage = document.getElementById("product-image");

    productNameField.textContent = selectedProduct.productName;
    productPriceField.textContent = `$${selectedProduct.price}`;
    productImage.src = selectedProduct.imageUrl;
  }
});

// form-validations
function showPopup() {
  document.getElementById("popup_main").style.display = "flex";
}

document
  .getElementById("buy-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const email = document.getElementById("email").value.trim();
    const pincode = document.getElementById("pincode").value.trim();
    const city = document.getElementById("city").value.trim();
    const deliveryDate = document.getElementById("delivery-date").value.trim();
    const addressType = document.querySelector(
      'input[name="address-type"]:checked'
    );
    const address = document.getElementById("address").value.trim();

    document.getElementById("name-Error").textContent = "";
    document.getElementById("mobile-Error").textContent = "";
    document.getElementById("email-Error").textContent = "";
    document.getElementById("pincode-Error").textContent = "";
    document.getElementById("city-Error").textContent = "";
    document.getElementById("delivery-date-Error").textContent = "";
    document.getElementById("address-type-Error").textContent = "";
    document.getElementById("address-Error").textContent = "";
    let valid = true;

    //name-validation
    if (name === "") {
      valid = false;
      document.getElementById("name-Error").textContent = "Name is Required";
    } else if (name.length < 3) {
      valid = false;
      document.getElementById("name-Error").textContent =
        "Name should be more than 3 Characters";
    } else if (name.length > 20) {
      valid = false;
      document.getElementById("name-Error").textContent =
        "Name should be less than 20 Characters";
    }

    //phone-validation
    if (phone === "") {
      valid = false;
      document.getElementById("mobile-Error").textContent =
        "Mobile is required";
    } else if (phone.length < 10) {
      valid = false;
      document.getElementById("mobile-Error").textContent =
        "Please enter a valid Mobile Number";
    } else if (phone.length > 12) {
      valid = false;
      document.getElementById("mobile-Error").textContent =
        "Please enter a valid Mobile Number";
    }

    //email-validation
    if (email === "") {
      valid = false;
      document.getElementById("email-Error").textContent = "Email is required";
    } else if (!email.includes("@") || !email.includes(".")) {
      valid = false;
      document.getElementById("email-Error").textContent =
        "Please enter a valid email";
    }

    //pincode-validation
    if (pincode === "") {
      valid = false;
      document.getElementById("pincode-Error").textContent =
        "Pincode is required";
    } else if (pincode.length !== 6) {
      valid = false;
      document.getElementById("pincode-Error").textContent =
        "Please enter a valid 6 digit Pincode";
    }

    //city-validation
    if (city === "") {
      valid = false;
      document.getElementById("city-Error").textContent = "City is required";
    }

    //delivery-date-validation
    if (deliveryDate === "") {
      valid = false;
      document.getElementById("delivery-date-Error").textContent =
        "Delivery Date is required";
    }

    //radio-btn-validation
    if (!addressType) {
      valid = false;
      document.getElementById("address-type-Error").textContent =
        "Address Type is required";
    }

    //address-validation
    if (address === "") {
      valid = false;
      document.getElementById("address-Error").textContent =
        "Address is required";
    } else if (address.length < 10) {
      valid = false;
      document.getElementById("address-Error").textContent =
        "Please enter full Address";
    }

    if (valid) {
      showPopup();
    }
  });

// Popup-msg
const closePopupButton = document.getElementById("closePopup");

closePopupButton.addEventListener("click", () => {
  document.getElementById("popup_main").style.display = "none";
});
