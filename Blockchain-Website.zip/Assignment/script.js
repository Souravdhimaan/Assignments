const form = document.getElementById("myForm");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const address = document.getElementById("address").value;

  //form_validations

  // Name_validation
  let valid = true;
  if (!name) {
    valid = false;
    document.getElementById("nameError").textContent = "Name is Required";
  } else if (name.length < 3) {
    valid = false;
    document.getElementById("nameError").textContent =
      "Name should be more than 3 Characters";
  } else if (name.length > 20) {
    valid = false;
    document.getElementById("nameError").textContent =
      "Name should be less than 20 Characters";
  } else {
    document.getElementById("nameError").textContent = "";
  }

  // E-mail_validation
  if (!email) {
    valid = false;
    document.getElementById("emailError").textContent = "E-mail is Required";
  } else {
    document.getElementById("emailError").textContent = "";
  }

  // Phone_validation
  if (!phone) {
    valid = false;
    document.getElementById("phoneError").textContent = "Phone is Required";
  } else if (phone.length < 10) {
    valid = false;
    document.getElementById("phoneError").textContent =
      "Please enter Valid Number";
  } else if (phone.length > 12) {
    valid = false;
    document.getElementById("phoneError").textContent =
      "Please enter Valid Number";
  } else {
    document.getElementById("phoneError").textContent = "";
  }

  // Address_validation
  if (!address) {
    valid = false;
    document.getElementById("addressError").textContent =
      "Please enter about your project";
  } else if (address.length < 0) {
    valid = false;
    document.getElementById("addressError").textContent =
      "Please enter full Address";
  } else {
    document.getElementById("addressError").textContent = "";
  }
});
